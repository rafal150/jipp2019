﻿using System;

namespace KonwerterZSQLiAZURE
{
    public class DBO
    {

        public DateTime? DataGenerowania { get; set; }

        public string LogKonwersji { get; set; }

        
    }
}